package com.hexaware;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FastxApplicationTests {

	@Test
	void contextLoads() {
	}

}
