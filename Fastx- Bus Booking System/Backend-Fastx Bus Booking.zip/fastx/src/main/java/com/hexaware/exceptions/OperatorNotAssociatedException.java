package com.hexaware.exceptions;

public class OperatorNotAssociatedException extends Exception{

	public OperatorNotAssociatedException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
}
