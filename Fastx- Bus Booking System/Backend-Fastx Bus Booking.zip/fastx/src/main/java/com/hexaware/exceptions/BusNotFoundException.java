package com.hexaware.exceptions;

public class BusNotFoundException extends Exception {
	public BusNotFoundException(String msg) {
		super(msg);
	}
}
