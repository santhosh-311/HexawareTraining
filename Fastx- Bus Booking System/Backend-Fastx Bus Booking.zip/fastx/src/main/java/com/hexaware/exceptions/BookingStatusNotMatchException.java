package com.hexaware.exceptions;

public class BookingStatusNotMatchException extends Exception {

	public BookingStatusNotMatchException(String msg) {
		super(msg);
	}
	
}
