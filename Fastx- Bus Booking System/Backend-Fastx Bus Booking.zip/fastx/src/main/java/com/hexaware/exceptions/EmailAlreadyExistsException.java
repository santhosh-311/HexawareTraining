package com.hexaware.exceptions;

public class EmailAlreadyExistsException extends Exception {

	public EmailAlreadyExistsException(String msg) {
		super(msg);
	}
	
}
