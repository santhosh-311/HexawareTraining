package com.hexaware.exceptions;

public class PhoneAlreadyExistsException extends Exception {

	public PhoneAlreadyExistsException(String msg) {
		super(msg);
	}
	
}
