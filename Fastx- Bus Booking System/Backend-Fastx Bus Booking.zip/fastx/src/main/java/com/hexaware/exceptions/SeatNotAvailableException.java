package com.hexaware.exceptions;

public class SeatNotAvailableException extends Exception {

	public SeatNotAvailableException(String msg) {
		super(msg);
	}

	
}
