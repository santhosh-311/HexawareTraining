package com.hexaware.exceptions;

public class BusAlreadyExistException extends Exception {
	public BusAlreadyExistException(String msg) {
		super(msg);
	}
}
