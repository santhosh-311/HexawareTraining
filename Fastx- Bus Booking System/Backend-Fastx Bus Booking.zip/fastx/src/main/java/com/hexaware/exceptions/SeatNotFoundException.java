package com.hexaware.exceptions;

public class SeatNotFoundException extends Exception {
	public SeatNotFoundException(String msg){
		super(msg);
	}

}