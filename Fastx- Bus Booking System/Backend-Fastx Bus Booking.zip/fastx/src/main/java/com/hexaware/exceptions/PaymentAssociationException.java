package com.hexaware.exceptions;

public class PaymentAssociationException extends Exception {

	public PaymentAssociationException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
	
}
